"""Backtesting module for evaluating betting strategies."""
from .engine import BacktestEngine, BacktestResult, Trade, Position
from .strategies import (
    MeanReversionStrategy,
    MomentumStrategy,
    BreakoutStrategy,
    MachineLearningStrategy
)

__all__ = [
    'BacktestEngine',
    'BacktestResult',
    'Trade',
    'Position',
    'MeanReversionStrategy',
    'MomentumStrategy',
    'BreakoutStrategy',
    'MachineLearningStrategy'
]
