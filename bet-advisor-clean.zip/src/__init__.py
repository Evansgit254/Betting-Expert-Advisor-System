"""Betting Expert Advisor - Automated sports betting system with ML predictions."""
__version__ = "1.0.0"
