"""Risk management and bankroll management module."""
from src.config import settings
from src.utils import get_logger

logger = get_logger(__name__)


def kelly_fraction(win_prob: float, odds: float, bankroll: float) -> float:
    """Calculate stake using fractional Kelly criterion.
    
    Args:
        win_prob: Probability of winning (0-1)
        odds: Decimal odds
        bankroll: Current bankroll
        
    Returns:
        Recommended stake amount
    """
    # Decimal odds to fractional (b)
    b = odds - 1.0
    
    if b <= 0:
        logger.debug(f"Invalid odds {odds}, returning 0 stake")
        return 0.0
    
    # Calculate edge
    edge = win_prob - (1.0 / odds)
    
    if edge <= 0:
        logger.debug(f"No edge (prob={win_prob}, odds={odds}), returning 0 stake")
        return 0.0
    
    # Full Kelly
    full_kelly = edge / b
    
    # Apply fractional Kelly for conservative sizing
    fractional_kelly = full_kelly * settings.DEFAULT_KELLY_FRACTION
    
    # Convert to stake amount
    stake = fractional_kelly * bankroll
    
    # Cap to MAX_STAKE_FRAC of bankroll
    max_stake = settings.MAX_STAKE_FRAC * bankroll
    stake = min(stake, max_stake)
    
    # Ensure non-negative
    stake = max(0.0, stake)
    
    logger.debug(
        f"Kelly stake: prob={win_prob:.3f}, odds={odds:.2f}, "
        f"edge={edge:.3f}, stake={stake:.2f} ({stake/bankroll*100:.1f}% of bankroll)"
    )
    
    return stake


def stake_from_bankroll(win_prob: float, odds: float, bankroll: float) -> float:
    """Calculate recommended stake from bankroll.
    
    This is the main entry point for stake calculation.
    
    Args:
        win_prob: Probability of winning (0-1)
        odds: Decimal odds
        bankroll: Current bankroll
        
    Returns:
        Recommended stake amount
    """
    return kelly_fraction(win_prob, odds, bankroll)


def validate_bet(
    win_prob: float,
    odds: float,
    stake: float,
    bankroll: float,
    daily_loss: float = 0.0,
    open_bets: int = 0
) -> tuple[bool, str]:
    """Validate a bet against all risk management rules.
    
    Args:
        win_prob: Probability of winning
        odds: Decimal odds
        stake: Proposed stake
        bankroll: Current bankroll
        daily_loss: Today's accumulated loss
        open_bets: Current number of open bets
        
    Returns:
        Tuple of (is_valid, reason)
    """
    # Check probability range
    if not (0.0 < win_prob < 1.0):
        return False, f"Invalid probability: {win_prob}"
    
    # Check odds range
    if odds < 1.01:
        return False, f"Odds too low: {odds}"
    
    if odds > 1000:
        return False, f"Odds too high: {odds}"
    
    # Check stake is positive
    if stake <= 0:
        return False, f"Invalid stake: {stake}"
    
    # Check stake doesn't exceed max fraction of bankroll
    if stake > bankroll * settings.MAX_STAKE_FRAC:
        return False, f"Stake {stake} exceeds max {settings.MAX_STAKE_FRAC*100}% of bankroll"
    
    # Check stake doesn't exceed bankroll
    if stake > bankroll:
        return False, f"Stake {stake} exceeds bankroll {bankroll}"
    
    # Check daily loss limit
    if daily_loss >= settings.DAILY_LOSS_LIMIT:
        return False, f"Daily loss limit reached: {daily_loss} >= {settings.DAILY_LOSS_LIMIT}"
    
    # Check max open bets limit
    if open_bets >= settings.MAX_OPEN_BETS:
        return False, f"Max open bets reached: {open_bets} >= {settings.MAX_OPEN_BETS}"
    
    # Check edge exists (expected value > 0)
    edge = win_prob * (odds - 1) - (1 - win_prob)
    if edge <= 0:
        return False, f"No positive edge: EV={edge:.4f}"
    
    return True, "Valid"


def calculate_expected_value(win_prob: float, odds: float) -> float:
    """Calculate expected value of a bet.
    
    EV = (probability of winning × amount won per bet) - (probability of losing × amount lost per bet)
    
    Args:
        win_prob: Probability of winning (0-1)
        odds: Decimal odds
        
    Returns:
        Expected value as fraction of stake
    """
    ev = win_prob * (odds - 1) - (1 - win_prob)
    return ev


def calculate_variance(win_prob: float, odds: float) -> float:
    """Calculate variance of a bet outcome.
    
    Args:
        win_prob: Probability of winning
        odds: Decimal odds
        
    Returns:
        Variance in units of stake
    """
    # Profit if win, loss if lose
    profit_if_win = odds - 1
    loss_if_lose = -1
    
    # Expected value
    ev = calculate_expected_value(win_prob, odds)
    
    # Variance = E[X^2] - E[X]^2
    e_x_squared = (
        win_prob * (profit_if_win ** 2) +
        (1 - win_prob) * (loss_if_lose ** 2)
    )
    variance = e_x_squared - (ev ** 2)
    
    return variance


def calculate_sharpe_ratio(win_prob: float, odds: float) -> float:
    """Calculate Sharpe-like ratio for a bet.
    
    Args:
        win_prob: Probability of winning
        odds: Decimal odds
        
    Returns:
        Sharpe ratio (EV / sqrt(variance))
    """
    ev = calculate_expected_value(win_prob, odds)
    variance = calculate_variance(win_prob, odds)
    
    if variance <= 0:
        return 0.0
    
    import math
    sharpe = ev / math.sqrt(variance)
    return sharpe
