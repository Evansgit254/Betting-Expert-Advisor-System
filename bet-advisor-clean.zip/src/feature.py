"""Feature engineering for betting predictions."""
import pandas as pd
import numpy as np
import pytz
from datetime import datetime
from typing import Optional, List

from src.utils import get_logger

logger = get_logger(__name__)


def build_features(fixtures_df: pd.DataFrame, odds_df: pd.DataFrame) -> pd.DataFrame:
    """Build features from fixtures and odds data.
    
    Works with both synthetic data and live API data.
    
    Args:
        fixtures_df: DataFrame with fixture information
        odds_df: DataFrame with odds information
        
    Returns:
        DataFrame with engineered features
    """
    logger.info(f"Building features from {len(fixtures_df)} fixtures and {len(odds_df)} odds")
    
    if fixtures_df.empty:
        return pd.DataFrame()
    
    # Start with fixtures
    df = fixtures_df.copy()
    
    # Join with odds if available
    if not odds_df.empty:
        # Filter to only standard selections BEFORE pivoting
        standard_selections = ['home', 'away', 'draw']
        odds_filtered = odds_df[odds_df['selection'].isin(standard_selections)].copy()
        
        if not odds_filtered.empty:
            # CRITICAL: Convert odds to numeric before pivoting
            odds_filtered['odds'] = pd.to_numeric(odds_filtered['odds'], errors='coerce')
            
            # Drop any rows where odds couldn't be converted
            odds_filtered = odds_filtered.dropna(subset=['odds'])
            
            # Pivot odds to get home/away/draw odds in columns
            odds_pivot = odds_filtered.pivot_table(
                index='market_id',
                columns='selection',
                values='odds',
                aggfunc='first'  # Take first value if duplicates
            ).reset_index()
            
            # Rename columns to avoid confusion with team name columns
            rename_map = {}
            for col in odds_pivot.columns:
                if col in standard_selections:
                    rename_map[col] = f'{col}_odds'
            
            if rename_map:
                odds_pivot = odds_pivot.rename(columns=rename_map)
            
            # Merge with fixtures
            df = df.merge(odds_pivot, on='market_id', how='left')
            
            # For LIVE API data, also get the true probabilities if available
            # (This won't exist for live data, only for synthetic)
            if 'true_prob' in odds_filtered.columns:
                prob_pivot = odds_filtered.pivot_table(
                    index='market_id',
                    columns='selection',
                    values='true_prob',
                    aggfunc='first'
                ).reset_index()
                
                prob_rename = {}
                for col in prob_pivot.columns:
                    if col in standard_selections:
                        prob_rename[col] = f'{col}_prob'
                
                if prob_rename:
                    prob_pivot = prob_pivot.rename(columns=prob_rename)
                    df = df.merge(prob_pivot, on='market_id', how='left')
    
    # Add basic features
    df = add_odds_features(df)
    df = add_temporal_features(df)
    df = add_team_features(df)
    
    logger.info(f"Generated {len(df.columns)} features")
    return df


"""
CRITICAL FIX: The issue is that we're calculating probabilities FROM the odds,
so any noise in odds is perfectly cancelled by calculating prob = 1/odds.

Instead, we need to store the TRUE probability (before margin/noise) and 
use THAT for EV calculations, while using the NOISY odds for betting.

Replace the add_odds_features function in src/feature.py with this:
"""

def add_odds_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add odds-derived features.
    
    Features:
    - Implied probabilities from odds
    - Bookmaker margin
    - Odds differentials
    
    Handles both synthetic data (with true_prob) and live data (without)
    """
    df = df.copy()
    
    # Convert odds columns to numeric (in case they're strings)
    for col in ['home_odds', 'away_odds', 'draw_odds']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    # Calculate implied probabilities from odds
    # These are what the bookmaker thinks
    if 'home_odds' in df.columns:
        df['implied_prob_home'] = 1.0 / df['home_odds'].replace(0, np.inf)
        df['implied_prob_home'] = df['implied_prob_home'].clip(0, 1)
    
    if 'away_odds' in df.columns:
        df['implied_prob_away'] = 1.0 / df['away_odds'].replace(0, np.inf)
        df['implied_prob_away'] = df['implied_prob_away'].clip(0, 1)
    
    if 'draw_odds' in df.columns:
        df['implied_prob_draw'] = 1.0 / df['draw_odds'].replace(0, np.inf)
        df['implied_prob_draw'] = df['implied_prob_draw'].clip(0, 1)
    
    # Calculate bookmaker margin
    prob_cols = ['implied_prob_home', 'implied_prob_away', 'implied_prob_draw']
    available_probs = [c for c in prob_cols if c in df.columns]
    
    if available_probs:
        df['bookmaker_margin'] = df[available_probs].sum(axis=1) - 1.0
        
        # Create normalized probabilities (remove bookmaker margin)
        # These are our best estimate of true probabilities from the odds
        total_implied = df[available_probs].sum(axis=1)
        
        # Use these normalized probabilities as our predictions
        # (In production, you'd use ML model predictions instead)
        if 'home_prob' not in df.columns:  # Only if not already set from true_prob
            if 'implied_prob_home' in df.columns:
                df['home_prob'] = df['implied_prob_home'] / total_implied
                df['home_prob'] = df['home_prob'].clip(0, 1)
        
        if 'away_prob' not in df.columns:
            if 'implied_prob_away' in df.columns:
                df['away_prob'] = df['implied_prob_away'] / total_implied
                df['away_prob'] = df['away_prob'].clip(0, 1)
        
        if 'draw_prob' not in df.columns:
            if 'implied_prob_draw' in df.columns:
                df['draw_prob'] = df['implied_prob_draw'] / total_implied
                df['draw_prob'] = df['draw_prob'].clip(0, 1)
    
    # Favorite indicator
    if 'home_odds' in df.columns and 'away_odds' in df.columns:
        df['home_favorite'] = (df['home_odds'] < df['away_odds']).astype(int)
        df['odds_differential'] = df['away_odds'] - df['home_odds']
        df['odds_ratio'] = df['away_odds'] / df['home_odds']
    
    return df


def add_temporal_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add time-based features."""
    if 'start' not in df.columns:
        return df
    
    # Convert to datetime if needed
    if not pd.api.types.is_datetime64_any_dtype(df['start']):
        df['start'] = pd.to_datetime(df['start'])
    
    # Handle both timezone-aware and naive datetimes
    now = datetime.now(pytz.utc)
    
    # Check if start column is timezone-aware
    if df['start'].dt.tz is None:
        # Timezone-naive - use naive datetime for comparison
        now = datetime.now()
    
    df['day_of_week'] = df['start'].dt.dayofweek
    df['hour_of_day'] = df['start'].dt.hour
    df['is_weekend'] = (df['day_of_week'] >= 5).astype(int)
    df['days_until_match'] = (df['start'] - now).dt.total_seconds() / 86400
    
    return df


def add_team_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add team-based features.
    
    In a real implementation, this would include:
    - Recent form (last N matches)
    - Head-to-head record
    - League position
    - Goals scored/conceded
    - Home/away performance
    
    For now, we'll add placeholder features.
    """
    df = df.copy()
    
    if 'home' not in df.columns or 'away' not in df.columns:
        return df
    
    # Team strength proxies (in production, load from historical data)
    # For now, use hash-based pseudo-random features for demonstration
    df['home_strength'] = df['home'].apply(lambda x: (hash(x) % 100) / 100.0)
    df['away_strength'] = df['away'].apply(lambda x: (hash(x) % 100) / 100.0)
    df['strength_differential'] = df['home_strength'] - df['away_strength']
    
    return df


def select_features(df: pd.DataFrame, feature_names: Optional[List[str]] = None) -> pd.DataFrame:
    """Select specific features for modeling.
    
    Args:
        df: DataFrame with all features
        feature_names: List of feature names to select (None = auto-select numeric)
        
    Returns:
        DataFrame with selected features only
    """
    if feature_names is not None:
        # Filter to only include features that exist in the dataframe
        available_features = [f for f in feature_names if f in df.columns]
        return df[available_features].fillna(0)
    
    # Auto-select core numeric features that should be stable across data sources
    # Use the minimal set of features that work across all data sources
    core_features = [
        # Odds features - prioritize the ones that exist in both synthetic and live
        'draw_odds',  # Draw odds (numeric)
        'bookmaker_margin',  # Margin
        'implied_prob_draw',  # Draw probability
        # Temporal features
        'day_of_week', 'hour_of_day', 'is_weekend', 'days_until_match',
    ]
    
    # Add home/away odds (handle both naming conventions)
    for home_col in ['home_odds']:
        if home_col in df.columns:
            core_features.insert(0, home_col)
            break
    for away_col in ['away_odds']:
        if away_col in df.columns:
            core_features.insert(1, away_col)
            break
    
    # Find which core features are available
    available = [f for f in core_features if f in df.columns]
    
    if not available:
        # Fallback: select all numeric features, excluding IDs and metadata
        exclude_cols = ['market_id', 'start', 'sport', 'league', 'selection', 'provider', 
                       'home', 'away',  # team names (strings)
                       'home_strength', 'away_strength', 'strength_differential',  # Pseudo features
                       'home_favorite', 'odds_differential', 'odds_ratio']  # Derived features
        numeric_df = df.select_dtypes(include=[np.number])
        available = [c for c in numeric_df.columns if c not in exclude_cols]
    
    # Ensure only numeric data is returned
    result = df[available].copy()
    result = result.select_dtypes(include=[np.number]).fillna(0)
    return result


def prepare_training_data(df: pd.DataFrame, target_col: str = 'result') -> tuple:
    """Prepare feature matrix and target vector for training.
    
    Args:
        df: DataFrame with features and target
        target_col: Name of target column
        
    Returns:
        Tuple of (X, y) where X is feature matrix and y is target vector
    """
    if target_col not in df.columns:
        raise ValueError(f"Target column '{target_col}' not found in DataFrame")
    
    y = df[target_col]
    X = select_features(df.drop(columns=[target_col]))
    
    logger.info(f"Prepared training data: X shape {X.shape}, y shape {y.shape}")
    return X, y
