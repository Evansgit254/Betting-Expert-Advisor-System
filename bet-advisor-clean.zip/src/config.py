"""Configuration management using pydantic and environment variables."""
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    ENV: str = "development"
    DB_URL: str = "sqlite:///./data/bets.db"
    BOOKIE_API_BASE_URL: Optional[str] = None
    BOOKIE_API_KEY: Optional[str] = None
    MODE: str = "DRY_RUN"
    DEFAULT_KELLY_FRACTION: float = 0.2
    MAX_STAKE_FRAC: float = 0.05
    DAILY_LOSS_LIMIT: float = 1000.0
    MAX_OPEN_BETS: int = 10
    
    # TheOddsAPI settings
    THEODDS_API_KEY: Optional[str] = None
    THEODDS_API_BASE: str = "https://api.the-odds-api.com/v4"
    
    # Betfair settings
    BETFAIR_API_BASE: str = "https://api.betfair.com"
    BETFAIR_APP_KEY: Optional[str] = None
    BETFAIR_SESSION_TOKEN: Optional[str] = None
    
    # HTTP settings
    HTTP_TIMEOUT: int = 10
    
    # Logging
    LOG_LEVEL: str = "INFO"

    TELEGRAM_BOT_TOKEN: str | None = None  # Optional: Bot token for alerting
    TELEGRAM_CHAT_ID: str | None = None    # Optional: Chat ID for alerting

    class Config:
        """Pydantic configuration."""
        env_file = ".env"
        case_sensitive = True


settings = Settings()
