"""Database models and ORM layer using SQLAlchemy with enhanced error handling and retries."""
import logging
from contextlib import contextmanager
from datetime import datetime, timezone, timedelta, date, time
from typing import Optional, List, Dict, Any, TypeVar, Type, Callable, cast, Generator, Union
from datetime import datetime, timezone, timedelta, date, time

from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, JSON, Boolean, event, func
from sqlalchemy.orm import declarative_base, sessionmaker, Session, scoped_session
from sqlalchemy.exc import SQLAlchemyError, OperationalError, IntegrityError
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    RetryCallState,
    RetryError
)

from src.config import settings
from src.utils import utc_now, DBUnavailableError
from src.monitoring import send_alert

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Type variable for generic function return type
T = TypeVar('T')

# Retry configuration
DB_RETRY_ATTEMPTS = 3
DB_RETRY_WAIT_MIN = 1  # seconds
DB_RETRY_WAIT_MAX = 5  # seconds

def before_retry_callback(retry_state: RetryCallState) -> None:
    """Log before retrying a database operation."""
    if retry_state.attempt_number > 1:
        logger.warning(
            "Retrying %s: attempt %s",
            retry_state.fn.__name__,
            retry_state.attempt_number,
            exc_info=retry_state.outcome.exception()
        )

def db_retry(retry_on: tuple[type[Exception], ...] = (SQLAlchemyError,)):
    """Decorator for retrying database operations on transient failures.
    
    Args:
        retry_on: Tuple of exception types to retry on
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @retry(
            stop=stop_after_attempt(DB_RETRY_ATTEMPTS),
            wait=wait_exponential(
                multiplier=1,
                min=DB_RETRY_WAIT_MIN,
                max=DB_RETRY_WAIT_MAX
            ),
            retry=retry_if_exception_type(retry_on),
            before_sleep=before_retry_callback,
            reraise=True
        )
        def wrapper(*args: Any, **kwargs: Any) -> T:
            try:
                return func(*args, **kwargs)
            except retry_on as e:
                logger.error(
                    "Database operation failed after %d attempts: %s",
                    DB_RETRY_ATTEMPTS,
                    str(e),
                    exc_info=True
                )
                raise
        return cast(Callable[..., T], wrapper)
    return decorator

@contextmanager
def handle_db_errors() -> Generator[Session, None, None]:
    """Context manager for handling database errors consistently.
    
    Yields:
        Database session
        
    Raises:
        SQLAlchemyError: If a database error occurs
    """
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except IntegrityError as e:
        session.rollback()
        logger.error("Database integrity error: %s", str(e), exc_info=True)
        send_alert(f"Database integrity error: {str(e)}", level='critical')
        raise
    except SQLAlchemyError as e:
        session.rollback()
        logger.error("Database error: %s", str(e), exc_info=True)
        send_alert(f"Database error (SQLAlchemyError): {str(e)}", level='critical')
        raise DBUnavailableError("Unrecoverable SQLAlchemy error") from e
    except Exception as e:
        session.rollback()
        logger.error("Unexpected error in database operation: %s", str(e), exc_info=True)
        send_alert(f"Unexpected DB error: {str(e)}", level='critical')
        raise DBUnavailableError("Unexpected database error") from e
    finally:
        session.close()

Base = declarative_base()
engine = create_engine(settings.DB_URL, echo=False, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


class BetRecord(Base):
    """Database model for bet records with full audit trail and strategy tracking."""
    
    __tablename__ = "bets"
    
    id = Column(Integer, primary_key=True, index=True)
    market_id = Column(String, index=True, nullable=False)
    selection = Column(String, nullable=False)
    stake = Column(Float, nullable=False)
    odds = Column(Float, nullable=False)
    result = Column(String, nullable=False, default='pending')  # 'win', 'loss', 'void', 'pending'
    profit_loss = Column(Float, nullable=True)
    placed_at = Column(DateTime, default=utc_now, nullable=False)
    settled_at = Column(DateTime, nullable=True)
    idempotency_key = Column(String, unique=True, index=True, nullable=True)
    is_dry_run = Column(Boolean, default=True, nullable=False)
    strategy_name = Column(String, index=True, nullable=True)  # Name of the strategy used
    strategy_params = Column(JSON, nullable=True)  # Strategy-specific parameters
    meta = Column(JSON, nullable=True)  # For any additional metadata
    
    def __repr__(self):
        return f"<BetRecord(id={self.id}, market={self.market_id}, stake={self.stake}, odds={self.odds})>"


class ModelMetadata(Base):
    """Track model training runs and hyperparameters."""
    
    __tablename__ = "model_metadata"
    
    id = Column(Integer, primary_key=True, index=True)
    model_name = Column(String, nullable=False)
    version = Column(String, nullable=False)
    trained_at = Column(DateTime, default=utc_now, nullable=False)
    hyperparameters = Column(JSON, nullable=True)
    metrics = Column(JSON, nullable=True)
    git_commit = Column(String, nullable=True)
    data_range_start = Column(DateTime, nullable=True)
    data_range_end = Column(DateTime, nullable=True)
    
    def __repr__(self):
        return f"<ModelMetadata(name={self.model_name}, version={self.version})>"


class StrategyPerformance(Base):
    """Track performance metrics for each betting strategy."""
    __tablename__ = "strategy_performance"
    
    id = Column(Integer, primary_key=True, index=True)
    strategy_name = Column(String, index=True, nullable=False)
    period_start = Column(DateTime, nullable=False, index=True)  # Start of the tracking period
    period_end = Column(DateTime, nullable=False, index=True)    # End of the tracking period
    
    # Performance metrics
    total_bets = Column(Integer, default=0)
    win_count = Column(Integer, default=0)
    loss_count = Column(Integer, default=0)
    void_count = Column(Integer, default=0)
    total_staked = Column(Float, default=0.0)
    total_returned = Column(Float, default=0.0)
    total_profit_loss = Column(Float, default=0.0)
    
    # Risk metrics
    max_drawdown = Column(Float, default=0.0)  # Maximum drawdown during the period
    sharpe_ratio = Column(Float, nullable=True)  # Risk-adjusted return
    
    # Additional metrics
    win_rate = Column(Float, default=0.0)  # win_count / (win_count + loss_count)
    profit_margin = Column(Float, default=0.0)  # total_profit_loss / total_staked
    
    # Metadata
    params = Column(JSON, nullable=True)  # Strategy parameters used
    created_at = Column(DateTime, default=utc_now, nullable=False)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now, nullable=False)
    
    __table_args__ = (
        # Ensure we don't have duplicate strategy metrics for the same period
        {'sqlite_autoincrement': True},
    )


class DailyStats(Base):
    """Track daily performance metrics."""
    
    __tablename__ = "daily_stats"
    
    id = Column(Integer, primary_key=True, index=True)
    date = Column(DateTime, unique=True, index=True, nullable=False)
    total_bets = Column(Integer, default=0)
    total_staked = Column(Float, default=0.0)
    total_profit_loss = Column(Float, default=0.0)
    win_count = Column(Integer, default=0)
    loss_count = Column(Integer, default=0)
    void_count = Column(Integer, default=0)
    starting_bankroll = Column(Float, nullable=True)
    ending_bankroll = Column(Float, nullable=True)
    
    # Strategy-specific metrics
    strategy_metrics = Column(JSON, nullable=True)  # Store per-strategy metrics as JSON
    
    def __repr__(self):
        return f"<DailyStats(date={self.date}, bets={self.total_bets}, p/l={self.total_profit_loss})>"


def init_db():
    """Initialize database schema. Creates all tables if they don't exist."""
    Base.metadata.create_all(bind=engine)


@contextmanager
def get_session() -> Generator[Session, None, None]:
    """Context manager for database sessions with automatic cleanup.
    
    Yields:
        Session: A database session
        
    Raises:
        SQLAlchemyError: If a database error occurs
    """
    with handle_db_errors() as session:
        yield session


@db_retry(retry_on=(SQLAlchemyError,))
def save_bet(
    market_id: str,
    selection: str,
    stake: float,
    odds: float,
    idempotency_key: Optional[str] = None,
    is_dry_run: bool = True,
    meta: Optional[dict] = None,
    strategy_name: Optional[str] = None,
    strategy_params: Optional[dict] = None
) -> BetRecord:
    """Save a bet to the database with idempotency check and retry logic.
    
    This function saves a bet to the database with proper validation and idempotency
    handling. If an idempotency_key is provided and a bet with the same key exists,
    the existing bet will be returned instead of creating a new one.
    
    Args:
        market_id: Unique market identifier (non-empty string)
        selection: Selected outcome (e.g., 'home', 'away', 'draw')
        stake: Bet amount (must be positive)
        odds: Decimal odds (must be >= 1.0)
        idempotency_key: Optional key to prevent duplicate submissions
        is_dry_run: If True, bet won't count towards statistics
        meta: Additional metadata as JSON
        
    Returns:
        BetRecord: The created or existing bet record
        
    Raises:
        ValueError: If input validation fails (e.g., invalid stake or odds)
        SQLAlchemyError: If database operation fails after retries
        
    Example:
        # Save a new bet
        bet = save_bet(
            market_id="1.23456789",
            selection="home",
            stake=100.0,
            odds=2.0,
            idempotency_key="unique-key-123",
            is_dry_run=True,
            meta={"strategy": "value_betting"}
        )
    """
    # Input validation
    if not isinstance(market_id, str) or not market_id.strip():
        raise ValueError("market_id must be a non-empty string")
    if not isinstance(selection, str) or not selection.strip():
        raise ValueError("selection must be a non-empty string")
    if not isinstance(stake, (int, float)) or stake <= 0:
        raise ValueError("stake must be a positive number")
    if not isinstance(odds, (int, float)) or odds < 1.0:
        raise ValueError("odds must be a number >= 1.0")
    if idempotency_key is not None and not isinstance(idempotency_key, str):
        raise ValueError("idempotency_key must be a string or None")
    # Input validation
    if not market_id or not selection:
        raise ValueError("market_id and selection are required")
    if not isinstance(stake, (int, float)) or stake <= 0:
        raise ValueError("stake must be a positive number")
    if not isinstance(odds, (int, float)) or odds < 1.0:
        raise ValueError("odds must be >= 1.0")
    
    with handle_db_errors() as session:
        # Check for existing bet with same idempotency key
        if idempotency_key:
            existing_bet = session.query(BetRecord).filter(
                BetRecord.idempotency_key == idempotency_key
            ).first()
            
            if existing_bet:
                logger.info("Found existing bet with idempotency key: %s", idempotency_key)
                # Create a detached copy to avoid session issues
                detached_existing = BetRecord(
                    id=existing_bet.id,
                    market_id=existing_bet.market_id,
                    selection=existing_bet.selection,
                    stake=existing_bet.stake,
                    odds=existing_bet.odds,
                    result=existing_bet.result,
                    profit_loss=existing_bet.profit_loss,
                    placed_at=existing_bet.placed_at,
                    settled_at=existing_bet.settled_at,
                    idempotency_key=existing_bet.idempotency_key,
                    is_dry_run=existing_bet.is_dry_run,
                    strategy_name=existing_bet.strategy_name,
                    strategy_params=existing_bet.strategy_params,
                    meta=existing_bet.meta
                )
                return detached_existing
                
        # If strategy_name is provided in meta, extract it
        if meta and 'strategy' in meta and not strategy_name:
            strategy_name = meta.get('strategy')
            if isinstance(strategy_name, dict):
                strategy_name = strategy_name.get('name')
                
        # If strategy_params are in meta, extract them
        if meta and 'strategy_params' in meta and not strategy_params:
            strategy_params = meta.get('strategy_params')
            if isinstance(strategy_params, str):
                import json
                try:
                    strategy_params = json.loads(strategy_params)
                except json.JSONDecodeError:
                    strategy_params = None
                    
        # Create new bet record with strategy info
        bet = BetRecord(
            market_id=market_id,
            selection=selection,
            stake=float(stake),  # Ensure float to avoid Decimal serialization issues
            odds=float(odds),
            idempotency_key=idempotency_key,
            is_dry_run=is_dry_run,
            strategy_name=strategy_name,
            strategy_params=strategy_params,
            meta=meta
        )
        
        session.add(bet)
        session.flush()
        session.refresh(bet)
        
        # Create a detached copy to avoid session issues
        detached_bet = BetRecord(
            id=bet.id,
            market_id=bet.market_id,
            selection=bet.selection,
            stake=bet.stake,
            odds=bet.odds,
            result=bet.result,
            profit_loss=bet.profit_loss,
            placed_at=bet.placed_at,
            settled_at=bet.settled_at,
            idempotency_key=bet.idempotency_key,
            is_dry_run=bet.is_dry_run,
            meta=bet.meta
        )
        
        logger.debug("Created new bet with ID: %s", bet.id)
        return detached_bet


@db_retry(retry_on=(SQLAlchemyError,))
def update_bet_result(bet_id: int, result: str, profit_loss: float) -> bool:
    """Update bet result after settlement with row-level locking and strategy tracking.
    
    This function ensures that only one update can happen at a time for a given bet_id
    by using a row-level lock. If the bet has already been settled, it will return False.
    
    The function uses a database-level lock to prevent race conditions when multiple
    processes try to update the same bet simultaneously. It also includes input
    validation and proper error handling.
    
    When a bet is settled, this function also updates the relevant strategy performance
    metrics if the bet was placed using a strategy.
    
    Args:
        bet_id: Database ID of the bet (must be a positive integer)
        result: Result string (must be one of: 'win', 'loss', 'void')
        profit_loss: Profit/loss amount (can be negative for losses)
        
    Returns:
        bool: 
            - True if the bet was successfully updated
            - False if the bet was already settled or not found
            
    Raises:
        ValueError: 
            - If bet_id is not a positive integer
            - If result is not one of the allowed values
            - If profit_loss is not a number
        SQLAlchemyError: If a database error occurs after retries
        
    Example:
        # Update a bet as a win with $50 profit
        success = update_bet_result(bet_id=123, result="win", profit_loss=50.0)
        if success:
            print("Bet updated successfully")
        else:
            print("Bet was already settled or not found")
    """
    # Input validation
    if not isinstance(bet_id, int) or bet_id <= 0:
        raise ValueError("bet_id must be a positive integer")
    if result not in ('win', 'loss', 'void'):
        raise ValueError("result must be one of: 'win', 'loss', 'void'")
    if not isinstance(profit_loss, (int, float)):
        raise ValueError("profit_loss must be a number")
    logger.debug("update_bet_result called with bet_id=%s, result=%s, profit_loss=%.2f", bet_id, result, profit_loss)
    
    # Input validation
    if not isinstance(bet_id, int) or bet_id <= 0:
        raise ValueError("bet_id must be a positive integer")
    if result not in ('win', 'loss', 'void'):
        raise ValueError("result must be one of: 'win', 'loss', 'void'")
    if not isinstance(profit_loss, (int, float)):
        raise ValueError("profit_loss must be a number")
    
    with handle_db_errors() as session:
        logger.debug("Inside handle_db_errors context, session: %s", session)
        
        # Use with_for_update to lock the row for update
        bet = (
            session.query(BetRecord)
            .filter_by(id=bet_id)
            .with_for_update(skip_locked=True)  # Skip rows that are already locked
            .first()
        )
        
        logger.debug("Queried bet: %s", bet)
        
        if not bet:
            logger.warning("Bet with ID %s not found", bet_id)
            return False
            
        # Check if bet is already settled
        logger.debug("Bet found: id=%s, result=%s, settled_at=%s", bet.id, bet.result, bet.settled_at)
        
        if bet.result != 'pending':
            logger.info("Bet %s is already settled with result: %s", bet_id, bet.result)
            return False
            
        # Get strategy info before updating
        strategy_name = bet.strategy_name
        strategy_params = bet.strategy_params
        
        # Update the bet with the result
        bet.result = result
        bet.profit_loss = profit_loss
        bet.settled_at = utc_now()
        
        # Update strategy performance metrics if this bet used a strategy
        if strategy_name and bet.result in ('win', 'loss', 'void') and not bet.is_dry_run:
            _update_strategy_performance(
                session=session,
                strategy_name=strategy_name,
                strategy_params=strategy_params,
                result=bet.result,
                stake=bet.stake,
                profit_loss=profit_loss,
                timestamp=bet.settled_at
            )
        
        try:
            session.commit()
            logger.debug("Successfully committed changes to bet %s", bet_id)
            return True
        except Exception as e:
            logger.error("Failed to commit changes to bet %s: %s", bet_id, str(e), exc_info=True)
            session.rollback()
            raise


@db_retry(retry_on=(SQLAlchemyError,))
def get_daily_loss(date: Optional[Union[datetime, date]] = None) -> float:
    """Calculate the total loss for a given date with proper timezone handling.
    
    This function calculates the total loss for all settled bets on the specified date.
    Only non-dry run bets with positive profit_loss values are considered as losses.
    The date is interpreted in UTC if no timezone is provided.
    
    Args:
        date: 
            - If None: Uses the current UTC date
            - If datetime: Uses the date part in UTC (converts to UTC if timezone-aware)
            - If date: Uses the start of that date in UTC
        
    Returns:
        float: 
            - Total loss as a positive number
            - 0.0 if there are no losses or if there's a net profit
            
    Raises:
        SQLAlchemyError: If a database error occurs after retries
        
    Example:
        # Get loss for today
        today_loss = get_daily_loss()
        
        # Get loss for a specific date (timezone-naive, assumed UTC)
        from datetime import datetime
        date = datetime(2023, 1, 1)
        loss = get_daily_loss(date)
        
        # Get loss for a specific date with timezone
        from datetime import datetime, timezone
        date = datetime(2023, 1, 1, tzinfo=timezone.utc)
        loss = get_daily_loss(date)
    """
    # Use current UTC date if none provided
    if date is None:
        date = utc_now()
    
    # Handle both date and datetime objects
    if isinstance(date, datetime):
        # If datetime has no timezone, assume UTC
        if date.tzinfo is None:
            date = date.replace(tzinfo=timezone.utc)
        # Convert to UTC if not already
        utc_date = date.astimezone(timezone.utc)
        start_of_day = utc_date.replace(hour=0, minute=0, second=0, microsecond=0)
    else:  # It's a date object
        # Create datetime at start of day in UTC
        start_of_day = datetime.combine(date, time.min).replace(tzinfo=timezone.utc)
    
    end_of_day = start_of_day + timedelta(days=1)
    
    with handle_db_errors() as session:
        # Start a new transaction
        with session.begin():
            # Query for settled bets on the given date
            bets = (
                session.query(BetRecord)
                .filter(
                    BetRecord.settled_at >= start_of_day,
                    BetRecord.settled_at < end_of_day,
                    BetRecord.is_dry_run.is_(False),
                    BetRecord.profit_loss.isnot(None)
                )
                .all()
            )
            
            # Calculate total loss (only positive values)
            total_loss = sum(bet.profit_loss for bet in bets if bet.profit_loss > 0)
            
            logger.debug(
                "Calculated daily loss for %s: %.2f (from %d bets", 
                start_of_day.date(), total_loss, len(bets)
            )
            
            return total_loss


@db_retry(retry_on=(SQLAlchemyError,))
def get_open_bets_count(exclude_dry_run: bool = True) -> int:
    """Get count of currently open (pending) bets.
    
    Args:
        exclude_dry_run: If True, exclude dry run bets from the count
        
    Returns:
        int: Number of open bets matching the criteria
        
    Raises:
        SQLAlchemyError: If database operation fails after retries
    """
    with handle_db_errors() as session:
        # Start a new transaction
        with session.begin():
            # Create the base query
            query = session.query(BetRecord).filter(BetRecord.result == 'pending')
            
            # Apply dry run filter if needed
            if exclude_dry_run:
                query = query.filter(BetRecord.is_dry_run.is_(False))
            
            # Execute the query and get the count
            count = query.count()
            logger.debug("Found %d open bets (exclude_dry_run=%s)", count, exclude_dry_run)
            return count


@db_retry(retry_on=(SQLAlchemyError,))
def _update_strategy_performance(
    session: Session,
    strategy_name: str,
    strategy_params: Optional[dict],
    result: str,
    stake: float,
    profit_loss: float,
    timestamp: datetime
) -> None:
    """Update strategy performance metrics for the given strategy.
    
    This is an internal function that updates the strategy performance metrics
    when a bet is settled. It should be called within an existing session.
    
    Args:
        session: Database session
        strategy_name: Name of the strategy
        strategy_params: Strategy parameters
        result: Bet result ('win', 'loss', or 'void')
        stake: Bet stake amount
        profit_loss: Profit or loss amount
        timestamp: When the bet was settled
    """
    # Get or create the strategy performance record for the current month
    month_start = datetime(timestamp.year, timestamp.month, 1, tzinfo=timezone.utc)
    next_month = (datetime(timestamp.year, timestamp.month, 1, tzinfo=timezone.utc) + 
                 timedelta(days=32)).replace(day=1)
    
    # Try to get existing record for this month
    perf = session.query(StrategyPerformance).filter(
        StrategyPerformance.strategy_name == strategy_name,
        StrategyPerformance.period_start == month_start,
        StrategyPerformance.period_end == next_month
    ).with_for_update().first()
    
    if not perf:
        # Create new record for this month
        perf = StrategyPerformance(
            strategy_name=strategy_name,
            period_start=month_start,
            period_end=next_month,
            params=strategy_params
        )
        session.add(perf)
    
    # Update metrics
    perf.total_bets += 1
    perf.total_staked += stake
    
    if result == 'win':
        perf.win_count += 1
        perf.total_returned += (stake + profit_loss)  # profit_loss is already net
    elif result == 'loss':
        perf.loss_count += 1
        perf.total_returned += (stake + profit_loss)  # profit_loss is negative for losses
    else:  # void
        perf.void_count += 1
        perf.total_returned += stake  # Return stake for void bets
    
    # Update calculated fields
    perf.total_profit_loss = perf.total_returned - perf.total_staked
    
    if (perf.win_count + perf.loss_count) > 0:
        perf.win_rate = perf.win_count / (perf.win_count + perf.loss_count)
    
    if perf.total_staked > 0:
        perf.profit_margin = perf.total_profit_loss / perf.total_staked
    
    # Note: max_drawdown and sharpe_ratio would be updated by a separate job
    # that analyzes the full trading history


def get_strategy_performance(
    strategy_name: Optional[str] = None,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> List[Dict[str, Any]]:
    """Get performance metrics for one or all strategies.
    
    Args:
        strategy_name: Optional name of the strategy to filter by
        start_date: Optional start date for the period
        end_date: Optional end date for the period
        
    Returns:
        List of dictionaries with strategy performance metrics
    """
    with get_session() as session:
        query = session.query(StrategyPerformance)
        
        if strategy_name:
            query = query.filter(StrategyPerformance.strategy_name == strategy_name)
            
        if start_date:
            query = query.filter(StrategyPerformance.period_start >= start_date)
            
        if end_date:
            query = query.filter(StrategyPerformance.period_end <= end_date)
        
        # Order by most recent period first
        query = query.order_by(StrategyPerformance.period_start.desc())
        
        results = query.all()
        
        return [{
            'strategy_name': r.strategy_name,
            'period_start': r.period_start,
            'period_end': r.period_end,
            'total_bets': r.total_bets,
            'win_count': r.win_count,
            'loss_count': r.loss_count,
            'void_count': r.void_count,
            'win_rate': r.win_rate,
            'total_staked': r.total_staked,
            'total_returned': r.total_returned,
            'total_profit_loss': r.total_profit_loss,
            'profit_margin': r.profit_margin,
            'max_drawdown': r.max_drawdown,
            'sharpe_ratio': r.sharpe_ratio,
            'params': r.params
        } for r in results]


@db_retry(retry_on=(SQLAlchemyError,))
def get_current_bankroll() -> float:
    """Calculate the current bankroll based on all settled bets.
    
    Returns:
        float: Current bankroll amount (starting from 0.0 if no bets placed)
        
    Raises:
        SQLAlchemyError: If database operation fails after retries
    """
    with get_session() as session:
        try:
            # Get sum of all settled bets' profit/loss
            result = session.query(
                func.coalesce(func.sum(BetRecord.profit_loss), 0.0)
            ).filter(
                BetRecord.result.in_(['win', 'loss', 'void']),
                BetRecord.is_dry_run == False
            ).scalar()
            
            return float(result) if result is not None else 0.0
            
        except SQLAlchemyError as e:
            logger.error("Error calculating current bankroll: %s", str(e), exc_info=True)
            raise
