"""Adapter for TheOddsAPI-style providers.

Implements fetch_fixtures and fetch_odds mapping to internal format.
Documentation: https://the-odds-api.com/liveapi/guides/v4/
"""
import os
import requests
import pandas as pd
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
from tenacity import retry, wait_exponential, stop_after_attempt
import time
from threading import Lock

from src.utils import get_logger

logger = get_logger(__name__)

API_KEY = os.getenv('THEODDS_API_KEY')
BASE = os.getenv('THEODDS_API_BASE', 'https://api.the-odds-api.com/v4')
TIMEOUT = int(os.getenv('HTTP_TIMEOUT', '10'))

# GLOBAL CIRCUIT BREAKER STATE
_CIRCUIT_BREAKER_LOCK = Lock()
_CIRCUIT_BREAKER_FAILURES = 0
_CIRCUIT_BREAKER_OPEN_UNTIL = 0
_CIRCUIT_BREAKER_COOLDOWN_SEC = 300  # 5 minutes
_ODDS_CACHE_FILE = '/tmp/theoddsapi_odds_cache.json'


@retry(wait=wait_exponential(multiplier=1, min=2, max=10), stop=stop_after_attempt(3))
def _get(path: str, params: Optional[Dict[str, Any]] = None) -> Any:
    """Make GET request with retry logic.
    
    Args:
        path: API endpoint path
        params: Query parameters
        
    Returns:
        JSON response
    """
    params = params or {}
    params['apiKey'] = API_KEY
    
    url = f"{BASE}{path}"
    logger.debug(f"GET {url} with params {params}")
    
    r = requests.get(url, params=params, timeout=TIMEOUT)
    r.raise_for_status()
    
    # Log remaining requests
    if 'x-requests-remaining' in r.headers:
        logger.info(f"TheOddsAPI requests remaining: {r.headers['x-requests-remaining']}")
    
    return r.json()


class TheOddsAPIAdapter:
    """Adapter for TheOddsAPI data source that implements DataSourceInterface."""
    
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None, sport: str = 'soccer_epl', region: str = 'uk'):
        """Initialize adapter.
        
        Args:
            api_key: API key (defaults to env var)
            base_url: Base URL (defaults to env var)
            sport: Default sport to fetch (default: soccer_epl for English Premier League)
            region: Default region for odds (default: uk)
        """
        global API_KEY, BASE
        API_KEY = api_key or API_KEY
        BASE = base_url or BASE
        
        self.api_key = API_KEY
        self.base_url = BASE
        self.default_sport = sport
        self.default_region = region
        
        if not self.api_key:
            raise ValueError("TheOddsAPI key not configured - set THEODDS_API_KEY environment variable")
            logger.warning("TheOddsAPI key not configured")
    
    def fetch_fixtures(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        sport: Optional[str] = None,
        region: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Fetch fixtures/events.
        
        Args:
            start_date: Filter events after this date
            end_date: Filter events before this date
            sport: Sport key (e.g., 'soccer_epl', 'basketball_nba') - uses default if not provided
            region: Region for odds (e.g., 'uk', 'us', 'au') - uses default if not provided
            
        Returns:
            List of fixture dictionaries
        """
        sport = sport or self.default_sport
        region = region or self.default_region
        logger.info(f"Fetching fixtures for sport={sport}, region={region}")
        
        try:
            data = _get(f"/sports/{sport}/odds", params={
                'regions': region,
                'markets': 'h2h',
                'oddsFormat': 'decimal'
            })
        except Exception as e:
            logger.error(f"Failed to fetch fixtures: {e}")
            return []
        
        fixtures = []
        for event in data:
            try:
                # Parse commence time
                commence_time = event.get('commence_time')
                if commence_time:
                    # Handle both ISO format with Z and +00:00
                    start_dt = datetime.fromisoformat(commence_time.replace('Z', '+00:00'))
                    if start_dt.tzinfo is None:
                        start_dt = start_dt.replace(tzinfo=timezone.utc)
                else:
                    start_dt = None
                
                # Apply date filters
                if start_date and start_dt and start_dt < start_date:
                    continue
                if end_date and start_dt and start_dt > end_date:
                    continue
                
                fixture = {
                    'market_id': event.get('id'),
                    'start': start_dt,
                    'home': event.get('home_team'),
                    'away': event.get('away_team'),
                    'sport': sport,
                    'league': event.get('sport_title', sport),
                    'raw': event,
                }
                fixtures.append(fixture)
            except Exception as e:
                logger.warning(f"Failed to parse event: {e}")
                continue
        
        logger.info(f"Fetched {len(fixtures)} fixtures")
        
        # Convert to DataFrame
        if not fixtures:
            return pd.DataFrame(columns=['market_id', 'home', 'away', 'start', 'sport', 'league'])
        
        df = pd.DataFrame(fixtures)
        # Drop raw column if present
        if 'raw' in df.columns:
            df = df.drop(columns=['raw'])
        
        return df
    
    def fetch_odds(
        self,
        market_ids: Optional[List[str]] = None,
        sport: Optional[str] = None,
        region: Optional[str] = None,
        allow_cached_fallback: bool = True
    ) -> pd.DataFrame:
        """Fetch current odds for markets with circuit breaker+cache fallback.
        Always returns a pandas DataFrame with columns:
        market_id, selection, odds, provider, last_update
        """
        global _CIRCUIT_BREAKER_FAILURES, _CIRCUIT_BREAKER_OPEN_UNTIL
        sport = sport or self.default_sport
        region = region or self.default_region
        logger.info(f"Fetching odds for sport={sport}, region={region}")
        now = time.time()

        def _normalize_odds(json_data: Any) -> pd.DataFrame:
            rows = []
            try:
                for event in json_data or []:
                    market_id = event.get('id')
                    last_update = event.get('commence_time')
                    event_home = (event.get('home_team') or "").strip().lower()
                    event_away = (event.get('away_team') or "").strip().lower()
                    # iterate bookmakers -> markets -> outcomes
                    for book in event.get('bookmakers', []) or []:
                        provider = book.get('title') or book.get('key') or 'Unknown'
                        for market in book.get('markets', []) or []:
                            if market.get('key') != 'h2h':
                                continue
                            for outcome in market.get('outcomes', []) or []:
                                selection_name = outcome.get('name')
                                price = outcome.get('price')
                                if selection_name and price:
                                    name_l = str(selection_name).strip().lower()
                                    # Prefer exact team-name matching first
                                    if event_home and name_l == event_home:
                                        selection = 'home'
                                    elif event_away and name_l == event_away:
                                        selection = 'away'
                                    elif name_l in ['draw', 'd', 'tie']:
                                        selection = 'draw'
                                    else:
                                        # fallback for providers that use generic labels
                                        if name_l in ['home', 'h']:
                                            selection = 'home'
                                        elif name_l in ['away', 'a']:
                                            selection = 'away'
                                        else:
                                            selection = selection_name
                                    rows.append({
                                        'market_id': market_id,
                                        'selection': selection,
                                        'odds': float(price),
                                        'provider': provider,
                                        'last_update': last_update
                                    })
            except Exception as e:
                logger.warning(f"Failed to normalize odds JSON: {e}")
            return pd.DataFrame(rows, columns=['market_id', 'selection', 'odds', 'provider', 'last_update'])

        with _CIRCUIT_BREAKER_LOCK:
            if now < _CIRCUIT_BREAKER_OPEN_UNTIL:
                logger.warning("CIRCUIT BREAKER OPEN - using cached odds, not making API calls.")
                if allow_cached_fallback:
                    try:
                        import json
                        with open(_ODDS_CACHE_FILE, 'r') as f:
                            cached = json.load(f)
                        return _normalize_odds(cached)
                    except Exception:
                        logger.error("Fallback cache unavailable/malformed!")
                        return pd.DataFrame(columns=['market_id', 'selection', 'odds', 'provider', 'last_update'])
                else:
                    return pd.DataFrame(columns=['market_id', 'selection', 'odds', 'provider', 'last_update'])
        try:
            data = _get(f"/sports/{sport}/odds", params={
                'regions': region,
                'markets': 'h2h',
                'oddsFormat': 'decimal'
            })
            with open(_ODDS_CACHE_FILE, 'w') as f:
                import json
                json.dump(data, f)
            with _CIRCUIT_BREAKER_LOCK:
                _CIRCUIT_BREAKER_FAILURES = 0
                _CIRCUIT_BREAKER_OPEN_UNTIL = 0
            return _normalize_odds(data)
        except Exception as e:
            with _CIRCUIT_BREAKER_LOCK:
                _CIRCUIT_BREAKER_FAILURES += 1
                logger.error(f"Failed to fetch odds: {e}")
                if _CIRCUIT_BREAKER_FAILURES >= 3:
                    _CIRCUIT_BREAKER_OPEN_UNTIL = now + _CIRCUIT_BREAKER_COOLDOWN_SEC
                    logger.error(f"CIRCUIT BREAKER ENGAGED for 5 minutes (until {time.ctime(_CIRCUIT_BREAKER_OPEN_UNTIL)})")
            if allow_cached_fallback:
                try:
                    import json
                    with open(_ODDS_CACHE_FILE, 'r') as f:
                        cached = json.load(f)
                    return _normalize_odds(cached)
                except Exception:
                    logger.error("Fallback cache unavailable/malformed!")
                    return pd.DataFrame(columns=['market_id', 'selection', 'odds', 'provider', 'last_update'])
            return pd.DataFrame(columns=['market_id', 'selection', 'odds', 'provider', 'last_update'])


def get_available_sports() -> List[Dict[str, Any]]:
    """Get list of available sports from TheOddsAPI.
    
    Returns:
        List of sport dictionaries with keys and titles
    """
    try:
        data = _get("/sports")
        logger.info(f"Available sports: {len(data)}")
        return data
    except Exception as e:
        logger.error(f"Failed to fetch sports: {e}")
        return []
