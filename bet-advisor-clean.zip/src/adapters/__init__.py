"""Adapters for external data sources and bookmakers."""
