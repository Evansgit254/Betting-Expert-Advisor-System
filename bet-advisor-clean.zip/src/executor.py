"""Bet execution module with mock and real bookmaker clients."""
import uuid
from datetime import datetime
from typing import Dict, Any, Optional
from abc import ABC, abstractmethod

from src.db import save_bet
from src.config import settings
from src.utils import get_logger, utc_now

logger = get_logger(__name__)


class BookmakerInterface(ABC):
    """Abstract interface for bookmaker clients."""
    
    @abstractmethod
    def place_bet(
        self,
        market_id: str,
        selection: str,
        stake: float,
        odds: float,
        idempotency_key: Optional[str] = None
    ) -> Dict[str, Any]:
        """Place a bet with the bookmaker.
        
        Args:
            market_id: Unique market identifier
            selection: Bet selection
            stake: Stake amount
            odds: Decimal odds
            idempotency_key: Unique key to prevent duplicates
            
        Returns:
            Response dictionary with status and bet details
        """
        pass


class MockBookie(BookmakerInterface):
    """Mock bookmaker for testing and simulation."""
    
    def place_bet(
        self,
        market_id: str,
        selection: str,
        stake: float,
        odds: float,
        idempotency_key: Optional[str] = None
    ) -> Dict[str, Any]:
        """Simulate bet placement.
        
        Always returns successful response for testing.
        """
        logger.info(f"[MOCK] Placing bet: {market_id} - {selection} @ {odds} for ${stake:.2f}")
        
        return {
            'status': 'accepted',
            'bet_id': str(uuid.uuid4()),
            'placed_at': utc_now().isoformat(),
            'market_id': market_id,
            'selection': selection,
            'stake': stake,
            'odds': odds,
            'potential_return': stake * odds,
            'provider': 'MockBookie'
        }


class Executor:
    """Main executor for bet placement with audit trail."""
    
    def __init__(self, client: Optional[BookmakerInterface] = None):
        """Initialize executor.
        
        Args:
            client: Bookmaker client (defaults to MockBookie)
        """
        self.client = client or MockBookie()
        logger.info(f"Initialized Executor with {self.client.__class__.__name__}")
    
    def execute(self, bet: Dict[str, Any], dry_run: bool = True) -> Dict[str, Any]:
        """Execute a bet placement.
        
        Args:
            bet: Bet dictionary with market_id, selection, stake, odds
            dry_run: If True, simulates placement; if False, places real bet
            
        Returns:
            Execution result dictionary
        """
        market_id = bet['market_id']
        selection = bet['selection']
        stake = bet['stake']
        odds = bet['odds']
        
        # Generate idempotency key
        idempotency_key = f"{market_id}-{selection}-{stake:.2f}-{odds:.2f}-{utc_now().timestamp()}"
        
        # Log execution attempt
        logger.info(
            f"{'[DRY-RUN] ' if dry_run else '[LIVE] '}"
            f"Executing bet: {market_id} - {selection} @ {odds} for ${stake:.2f}"
        )
        
        # Build metadata
        meta = {
            'ev': bet.get('ev'),
            'p': bet.get('p'),
            'expected_profit': bet.get('expected_profit'),
            'home': bet.get('home'),
            'away': bet.get('away'),
            'league': bet.get('league'),
        }
        
        # Execute or simulate
        if dry_run:
            result = {
                'status': 'dry_run',
                'idempotency_key': idempotency_key,
                'message': 'Bet simulated (DRY-RUN mode)',
                'timestamp': utc_now().isoformat()
            }
        else:
            # Check MODE setting
            if settings.MODE != 'LIVE':
                logger.warning("Attempted LIVE execution but MODE is not LIVE")
                result = {
                    'status': 'rejected',
                    'idempotency_key': idempotency_key,
                    'message': 'LIVE mode not enabled in settings',
                    'timestamp': utc_now().isoformat()
                }
            else:
                # Execute real bet
                try:
                    result = self.client.place_bet(
                        market_id, selection, stake, odds, idempotency_key
                    )
                    result['status'] = result.get('status', 'accepted')
                except Exception as e:
                    logger.error(f"Bet placement failed: {e}", exc_info=True)
                    result = {
                        'status': 'error',
                        'idempotency_key': idempotency_key,
                        'message': str(e),
                        'timestamp': utc_now().isoformat()
                    }
        
        # Persist to database
        try:
            bet_record = save_bet(
                market_id=market_id,
                selection=selection,
                stake=stake,
                odds=odds,
                idempotency_key=idempotency_key,
                is_dry_run=dry_run,
                meta={**meta, 'exec_result': result}
            )
            result['db_id'] = bet_record.id
            logger.info(f"Bet saved to database with ID {bet_record.id}")
        except Exception as e:
            logger.error(f"Failed to save bet to database: {e}", exc_info=True)
            result['db_error'] = str(e)
        
        return result
    
    def execute_batch(
        self,
        bets: list[Dict[str, Any]],
        dry_run: bool = True
    ) -> list[Dict[str, Any]]:
        """Execute multiple bets in batch.
        
        Args:
            bets: List of bet dictionaries
            dry_run: If True, simulates all placements
            
        Returns:
            List of execution results
        """
        logger.info(f"Executing batch of {len(bets)} bets (dry_run={dry_run})")
        
        results = []
        for bet in bets:
            result = self.execute(bet, dry_run=dry_run)
            results.append(result)
        
        # Summary
        successful = sum(1 for r in results if r['status'] in ['accepted', 'dry_run'])
        logger.info(
            f"Batch execution complete: {successful}/{len(results)} successful"
        )
        
        return results
