"""Verify database tables were created correctly."""
import os
import sys

# Add the project root to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import inspect
from src.db import engine

def verify_database():
    """Check that all expected tables exist in the database."""
    inspector = inspect(engine)
    tables = inspector.get_table_names()
    
    print(f"✅ Database file exists: {engine.url}")
    print(f"\n📊 Tables found ({len(tables)}):")
    
    for table in sorted(tables):
        columns = inspector.get_columns(table)
        print(f"\n  • {table}")
        print(f"    Columns: {len(columns)}")
        for col in columns[:5]:  # Show first 5 columns
            print(f"      - {col['name']}: {col['type']}")
        if len(columns) > 5:
            print(f"      ... and {len(columns) - 5} more columns")
    
    # Check expected tables
    expected_tables = ['bets', 'model_metadata', 'strategy_performance', 'daily_stats', 'alembic_version']
    missing = [t for t in expected_tables if t not in tables]
    
    if missing:
        print(f"\n⚠️  Missing expected tables: {missing}")
    else:
        print(f"\n✅ All expected tables present!")
    
    print(f"\n🎉 Database verification complete!")

if __name__ == "__main__":
    verify_database()
