"""Live odds tracking and monitoring system."""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path

from src.data_fetcher import DataFetcher
from src.adapters.theodds_api import TheOddsAPIAdapter
from src.feature import build_features, select_features
from src.model import ModelWrapper
from src.strategy import find_value_bets, apply_bet_filters
from src.config import settings
from src.utils import get_logger
from src.paths import LIVE_OPPORTUNITIES_FILE
from src.monitoring import send_alert
from src.executor import Executor

logger = get_logger(__name__)


class LiveOddsTracker:
    """Track live odds and alert on value opportunities."""
    
    def __init__(self, check_interval: int = 3600):
        """Initialize live tracker.
        
        Args:
            check_interval: Seconds between checks (default: 1 hour)
        """
        self.check_interval = check_interval
        self.model = ModelWrapper()
        self.opportunities_file = LIVE_OPPORTUNITIES_FILE
        
        # Load model
        try:
            self.model.load('models/model.pkl')
            logger.info("Model loaded successfully")
        except Exception as e:
            logger.warning(f"Could not load model: {e}")
            self.model = None
        
        # Initialize data fetcher with caching
        self.fetcher = DataFetcher(
            source=TheOddsAPIAdapter(api_key=settings.THEODDS_API_KEY)
        )
    
    def check_opportunities(self):
        """Check for current betting opportunities."""
        timestamp = datetime.now(timezone.utc)
        
        print(f"\n[{timestamp.strftime('%Y-%m-%d %H:%M:%S')}] Checking opportunities...")
        
        try:
            # Fetch data (uses cache automatically)
            fixtures = self.fetcher.get_fixtures()
            # Ensure fixtures is a DataFrame
            if isinstance(fixtures, list):
                fixtures = pd.DataFrame(fixtures)
            odds = self.fetcher.get_odds(list(fixtures['market_id']) if not fixtures.empty else [])
            if isinstance(odds, list):
                odds = pd.DataFrame(odds)

            print(f"  📊 {len(fixtures)} fixtures, {len(odds)} odds")

            if len(fixtures) == 0:
                print("  ❌ No fixtures found.")
                return []
            if len(odds) == 0:
                print("  ❌ No odds found.")
                return []
            
            # Build features
            features = build_features(fixtures, odds)
            
            # Make predictions
            if self.model is None:
                print("  ⚠️  No model - using normalized implied probabilities")
                if 'home_prob' not in features.columns:
                    if 'home_odds' in features.columns:
                        features['home_prob'] = 1.0 / features['home_odds']
                    else:
                        print("  ❌ Cannot calculate probabilities")
                        return []
            else:
                print("  🤖 Using ML model predictions...")
                X = features.drop(columns=['market_id', 'result'], errors='ignore')
                X_selected = select_features(X)
                try:
                    predictions = self.model.predict_proba(X_selected)
                    if len(predictions.shape) > 1 and predictions.shape[1] > 1:
                        features['home_prob'] = predictions[:, 1]
                    else:
                        features['home_prob'] = predictions
                    print(f"  ✅ Predictions: mean={features['home_prob'].mean():.3f}")
                except Exception as e:
                    print(f"  ⚠️  Model failed: {e}, using implied probs")
                    if 'home_odds' in features.columns:
                        features['home_prob'] = 1.0 / features['home_odds']
            
            # Verify columns
            if 'home_odds' not in features.columns or 'home_prob' not in features.columns:
                print(f"  ❌ Missing required columns")
                print(f"  Available: {list(features.columns)}")
                return []
            
            # Find value bets (returns list, not DataFrame)
            print(f"  🔍 Searching for value bets...")
            value_bets = find_value_bets(
                features,
                proba_col='home_prob',
                odds_col='home_odds',
                bank=10000.0,
                min_ev=0.01
            )
            if not isinstance(value_bets, list):
                value_bets = list(value_bets)

            # Apply filters (returns list)
            filtered = apply_bet_filters(
                value_bets,
                min_ev=0.001,
                min_confidence=0.50,
                max_total=10
            )
            if not isinstance(filtered, list):
                filtered = list(filtered)
            print(f"  ✅ {len(value_bets)} potential, {len(filtered)} after filters")
            
            if len(filtered) > 0:
                self.alert_opportunities(filtered)

            return filtered
            
        except Exception as e:
            logger.error(f"Error checking opportunities: {e}")
            print(f"  ❌ Error: {e}")
            return []
    
    def alert_opportunities(self, opportunities):
        """Alert user about opportunities - batch to Telegram and place paper bets automatically."""
        print("\n" + "="*70)
        print("  🚨 VALUE BET ALERT!")
        print("="*70 + "\n")
        batch_msgs = []
        executor = Executor()
        exec_results = []
        for i, bet in enumerate(opportunities, 1):
            print(f"{i}. {bet.get('home', 'TBD')} vs {bet.get('away', 'TBD')}")
            print(f"   Odds: {bet['odds']:.2f} | Prob: {bet['p']:.1%} | Edge: {bet['ev']:.2f} | Stake: ${bet['stake']:.2f}")
            print()
            batch_msgs.append(
                f"{i}. {bet.get('home', 'TBD')} vs {bet.get('away', 'TBD')}\n"
                f"   Odds: {bet['odds']:.2f} | Prob: {bet['p']:.1%} | Edge: {bet['ev']:.2f} | Stake: ${bet['stake']:.2f}"
            )
            # Place the paper (dry-run) bet automatically:
            result = executor.execute(bet, dry_run=True)
            exec_results.append(result)
        if batch_msgs:
            msg = "🚨 VALUE BET ALERTS (Batch)\n" + "\n".join(batch_msgs)
            send_alert(msg, level='info')
        print("="*70 + "\n")
        if exec_results:
            print("Paper bets automatically placed for all value opportunities (dry-run mode). Results:")
            for r in exec_results:
                print(f"  - {r.get('status', 'unknown')} | {r.get('message', '')} (DB ID: {r.get('db_id', 'N/A')})")
        import json
        with open(self.opportunities_file, 'w') as f:
            json.dump(opportunities, f, indent=2, default=str)
    
    def run_continuous(self):
        """Run continuous monitoring."""
        print("\n" + "="*70)
        print("  🔄 LIVE ODDS TRACKER")
        print("="*70)
        print(f"\n⏱️  Checking every {self.check_interval} seconds")
        print(f"📊 Model: {'Loaded ✅' if self.model else 'Not loaded ⚠️'}")
        print(f"🔔 Alerts: Console + {self.opportunities_file}")
        print("\nPress Ctrl+C to stop\n")
        
        try:
            while True:
                self.check_opportunities()
                
                next_check = datetime.now(timezone.utc) + timedelta(seconds=self.check_interval)
                print(f"  ⏰ Next check: {next_check.strftime('%H:%M:%S')}")
                
                time.sleep(self.check_interval)
                
        except KeyboardInterrupt:
            print("\n\n👋 Stopping tracker...")
    
    def run_once(self):
        """Run single check."""
        print("\n" + "="*70)
        print("  📊 SINGLE ODDS CHECK")
        print("="*70 + "\n")
        
        opportunities = self.check_opportunities()
        
        if not opportunities:
            print("\n✅ No value bets found at this time")
        
        print("\n" + "="*70 + "\n")
        
        return opportunities


def main():
    """Run live tracker."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Live Odds Tracker')
    parser.add_argument('--interval', type=int, default=3600,
                       help='Check interval in seconds (default: 3600 = 1 hour)')
    parser.add_argument('--once', action='store_true',
                       help='Run once instead of continuously')
    args = parser.parse_args()
    
    tracker = LiveOddsTracker(check_interval=args.interval)
    
    if args.once:
        tracker.run_once()
    else:
        tracker.run_continuous()


if __name__ == "__main__":
    main()
